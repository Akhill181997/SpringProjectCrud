package com.example.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.web.bind.annotation.*;

import com.example.demo.dao.AlienRepo;
import com.example.demo.model.Alien;
import com.example.demo.service.AlienService;

@RestController
//@RequestMapping("/api")--not mandate,i can be defined at method level as well
@Scope("request") //spring creates new instance for each http request ,its not mandate as well to define scope over controller
public class AlienController {

    @Autowired
    private AlienRepo repo;

    @Autowired
    private AlienService alienService;

    @GetMapping("/aliens")
    public List<Alien> getAliens() {
        alienService.printMessage(); 
        return repo.findAll();
    }

    @GetMapping("/aliens/{id}")
    public Optional<Alien> getAlien(@PathVariable("id") int id) {
        return repo.findById(id);
    }

    @PostMapping("/aliens")
    public Alien addAlien(@RequestBody Alien alien) {
        repo.save(alien);
        return alien;
    }

    @PutMapping("/aliens/{id}")
    public Alien updateAlien(@PathVariable int id, @RequestBody Alien alien) {
        Optional<Alien> existingAlien = repo.findById(id);
        if (existingAlien.isPresent()) {
            Alien updatedAlien = existingAlien.get();
            updatedAlien.setAname(alien.getAname());
            updatedAlien.setTech(alien.getTech());
            repo.save(updatedAlien);
            return updatedAlien;
        }
        return null;
    }

    @DeleteMapping("/aliens/{id}")
    public String deleteAlien(@PathVariable int id) {
        Alien a = repo.findById(id).orElse(null);
        if (a != null) {
            repo.delete(a);
            return "deleted";
        }
        return "alien not found";
    }

    
    @GetMapping("/alienByTech")
    public List<Alien> getAliensByTech(@RequestParam String tech) {
        return repo.findByTech(tech);
    }
}
