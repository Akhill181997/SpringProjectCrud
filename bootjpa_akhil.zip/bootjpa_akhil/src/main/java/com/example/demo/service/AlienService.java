package com.example.demo.service;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

@Service
@Scope("singleton") 
public class AlienService {

    public void printMessage() {
        System.out.println("AlienService - Singleton Bean Example");
    }
}
